import shutil  # библиотека для операций над файлами и директориями
import os


def directory_work():  # функция для работы с дирректориями (в том числе проверка)
    print("1 - Создать директорию" + "\n" + "2 - Удалить директорию")
    trigger = int(input())
    if trigger == 1:
        print("Введите полный путь до директории:" + '\n')
        name = str(input())
        if "Показ" not in name:
            print("Нельзя работать вне папки Показ")
        else:
            os.mkdir(name)
    if trigger == 2:
        print("Введите полный путь до папки:" + '\n')
        name = str(input())
        if "Показ" not in name:
            print("Нельзя работать вне папки Показ")
        else:
            os.rmdir(name)


def file_work():  # работаем с файлами
    print("Введите полный путь до файла:")
    trigger = str(input())
    if "Показ" not in trigger:
        print("Нельзя работать вне папки Показ")
    else:
        print(
            "1 - Создать файл" + "\n" + "2 - Удалить файл" + "\n" + "3 - Читать файл" + "\n" + "4 - Запись в файл" + "\n" + "5 - Переименовывание" + "\n" + "6 - Копирование")
        mark = int(input())
        if mark == 1:
            content = open(trigger, 'a+')
            content.close()
        elif mark == 2:
            os.remove(trigger)
        elif mark == 3:
            with open(trigger) as content:
                for line in content:
                    print(line)
        elif mark == 4:
            print("Введите строку для записи:")
            phrase = str(input())
            content = open(trigger, 'a+')
            content.write(phrase)
            content.close()
        elif mark == 5:
            print("Введите новое название (полный путь)")
            mark3 = str(input())
            os.rename(trigger, mark3)
        elif mark == 6:
            print("Введите новый путь (полный)")
            mark3 = str(input())
            shutil.copyfile(trigger, mark3)


while True:  # изначальная логика
    print(
        "1 - Создать/удалить директорию" + '\n' + "2 - Больше действий с файлами" + '\n' + "3 - Создать/удалить файл/Работа с файлом")
    ans = int(input())
    if ans == 1:
        directory_work()
    elif ans == 2:
        os.system(
            '"C:\WINDOWS\system32\cmd.exe"')  # командная строка
    elif ans == 3:
        file_work()