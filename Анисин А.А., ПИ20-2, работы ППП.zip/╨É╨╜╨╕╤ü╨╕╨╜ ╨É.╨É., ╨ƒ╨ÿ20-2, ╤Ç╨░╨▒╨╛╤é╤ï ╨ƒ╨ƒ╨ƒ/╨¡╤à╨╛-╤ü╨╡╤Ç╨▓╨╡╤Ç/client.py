import socket
from time import sleep  # импорт библиотек,  работа с сокетами  и функции ожидания

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)  # открытие сокета (IPV4, UPD)

def addr_port():  # выбираем конкретный адрес для дальнейшего подключения 
    addr = str(input("Введите IP-адрес: "))
    port_name = str(input("Введите порт:"))
    if(addr == ''):
        addr = "localhost"
    if(port_name == ''):
        port_name = 9055  #задаем порт 9055 как порт по умолчанию 
    return addr, int(port_name)

def add_new_user(): #функуция, отвечающая за добавление нового пользователя 
    global sock
    name = str(input("Имя пользователя: "))
    sock.send(name.encode()) # кодируем для последующей передачи данных
    password = str(input("Новый пароль: "))
    sock.send(password.encode())

def input_password():  # ввод пароля
    global sock
    data = 0
    while(data != "4"):
        password = str(input(f"Введите пароль: "))
        sock.send(password.encode())  # кодируем
        data = sock.recv(1024).decode("UTF-8")

def main():  # главная логика
    global sock, answer
    address, port = addr_port()
    sock.connect((address, port))
    while True:
        try:
            msg = input("Введите сообщение: ")
            sock.send(msg.encode())
            try:
                data = sock.recv(1024)
                msg = data.decode("UTF-8")
                if(msg == "1"): # ожидание различных команд от пользователя
                    add_new_user()
                elif(msg == "2"):
                    input_password()
                elif(msg == "3"):
                    data = sock.recv(1024)
                    print("Message from host: ", data.decode("UTF-8"))
            except:
                pass  # заглушка для использования try
            if(msg == "exit"):
                break
        except KeyboardInterrupt:  # перехватываем ошибку в целях корректного выхода  
            print("Вы отсоедины от сервера!")
            msg = "exit"
            sock.send(msg.encode())
            break

    sock.close()

if __name__ == "__main__":
	main()

# также см. файл серверной части server.py