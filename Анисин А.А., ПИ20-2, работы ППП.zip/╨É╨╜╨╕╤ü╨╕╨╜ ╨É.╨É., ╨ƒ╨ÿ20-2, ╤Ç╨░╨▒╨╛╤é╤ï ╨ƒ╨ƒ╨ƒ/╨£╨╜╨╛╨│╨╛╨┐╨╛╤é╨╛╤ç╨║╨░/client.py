import socket
import threading
from time import sleep
from threading import Thread
from time import sleep  # импорт библиотек для создания подключения, ожидания и реализации многопоточности

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM) # (IPV4, TCP)
client.setblocking(True)

def printmsg():  # ожидание ввода команд от пользователя, где
    while (True):
        try:
            name = client.recv(1024).decode("UTF-8")
            if(name == "1"):  # 1 -- добавление нового пользователя
                add_new_user()
                continue
            elif(name == "2"):   # 2 -- ввод пароля
                input_password()
                continue
            data = client.recv(1024).decode("UTF-8")
            print(f"Message from {name}: {data}")
        except (KeyboardInterrupt, ConnectionAbortedError):  # перехват ошибки для "плавного" выхода из программы
            print("Exit")
            break

def add_new_user():  # добавляем нового пользователя
    name = str(input("Введите свое имя: "))
    client.send(name.encode())  # кодируем для дальнейшей отправки
    password = str(input("Введите свой пароль: "))
    client.send(password.encode())  # кодируем для дальнейшей отправки

def input_password():  # функция для ввода пароля
    data = 0
    while(data != "4"):
        password = str(input(f"Введите пароль: "))
        client.send(password.encode())  # опять кодируем
        data = client.recv(1024).decode("UTF-8")

client.connect(("192.168.228.132", 9090))
checkdata = Thread(target=printmsg, daemon=True)
checkdata.start()
i = 0
while True:  # вечный цикл (т.к. это подключение)
    try:
        if(i == 0):
            sleep(5)
            i += 1
        msg = input()  # ввод и далее отправка закодированного сообщения
        client.send(msg.encode())
    except ConnectionAbortedError:  # постоянно проверяем подключение, перехватываем разрыв соединения и обеспечиваем "плавный" выход
        print("Connection disable!")
        break
    
client.close()

# также см. файл с серверной частью server.py