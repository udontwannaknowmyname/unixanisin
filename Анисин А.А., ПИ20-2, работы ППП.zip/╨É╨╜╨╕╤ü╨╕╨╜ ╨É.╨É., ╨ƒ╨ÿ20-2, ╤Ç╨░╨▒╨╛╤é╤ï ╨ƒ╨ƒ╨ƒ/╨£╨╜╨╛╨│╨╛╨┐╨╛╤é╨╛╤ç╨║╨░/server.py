import socket
from threading import Thread
import logging  # импортируем работу с многопоточностью, сокет для подключения и логирование (журналирование)

logging.basicConfig(level=logging.DEBUG, filename="log.log", filemode="w", encoding="UTF-8")  # ведение журнала в файл log.log
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # использование IPV4 и TCP
server.bind(("", 9050))  # подключение по порту 9050

users_in_file = []
auth = {}

commands = ['Журнал', 'Очистка журнала', 'Очистка всех пользователей', 'Полная остановка']  # думаю, из массива понятно за что ответственная каждая команда
commands_short = ['showlogs','clrlogs','clrID','stop']

def read_file():  # функция для чтения из файла
	global users_in_file
	with open("users.txt", mode="r", encoding="UTF-8") as r:  # открытие файла на чтение 
		file = u.readlines()
		for i in range(len(file)):  # проход по нему
			file[i] = file[i].strip("\n")
			file[i] = file[i].split(";")
	users_in_file = file

def write_in_file():  # запись в файл
	with open("users.txt", mode="w", encoding="UTF-8") as w:  # открываем файл на запись
		for i in range(len(users_in_file)):
			data = users_in_file[i][0] + ";" + users_in_file[i][1] + ";" + users_in_file[i][2] + "\n"
			u.writelines(data)

def serv_work(sock):  # ожидание команд от пользования 
    print('Сервер работает.')  # сами команды храняться в массиве, он объявлен сверху в "commands"
    print('Список доступных комманд:')
    for i in range(len(commands)):
        print(f"{i+1}. {commands[i]}: \"{commands_short[i]}\"")  # также есть короткие команды, которые хранятся в "comands_short"

    while True:  # перехват команд, в том числе неправильное написание\не существующие 
        command = input()
        if command not in commands_short:
            print('Нет такой команды.')
        elif 'showlogs' == command:
            with open('log.log', 'r') as file:
                for raw in file:
                    print(raw)
        elif 'clrlogs' == command:
            with open('log.log', 'w') as file:  # для справки по командам см. выше, массив commands
                pass
            print("Выполнено")
        elif 'clrID' == command:
            with open('users.txt', 'w') as file:
                file.writelines("")
            print("Выполнено")
        elif 'stop' == command:
            sock.close()
            break

class multiServer(Thread):   # многопоточный сервер
	users = []
	def __init__(self, sock, address):
		Thread.__init__(self)
		self.__sock = sock
		self.__address = address
		logging.info(f"Add new user: {address}")
		self.msg_name = self.func(self.__sock)

	def add_new_user(self, conn):   # добавление нового пользователя 
		conn.send(str.encode("1"))
		name = conn.recv(1024).decode("UTF-8")
		password = conn.recv(1024).decode("UTF-8")
		users_in_file.append([name, password, self.__address[0]])
		return (name)

	def func(self, conn):  # вход
		for i in range(len(users_in_file)):
			if(self.__address[0] == users_in_file[i][2]):
				msg_name = users_in_file[i][0]
				if(msg_name not in auth.keys()):
					while (True):
						conn.send(str.encode("2"))
						password = conn.recv(1024).decode("UTF-8")
						if(password == users_in_file[i][1]):
							auth[msg_name] = 1
							conn.send(str.encode("4"))
							break
				break
		else:
			msg_name = self.add_new_user(conn)
			auth[msg_name] = 1
		return (msg_name)

	def run(self):   # функиция, ответственная за сообщения 
		read_file()
		self.users.append(self)
		while (True):
			data = self.__sock.recv(1024).decode("UTF-8")
			if (data == "exit"):
				break
			logging.info(f"Message from {self.msg_name}: {data}")
			print(f"Message from {self.msg_name}: {data}")
			for con in self.users:
				con.__sock.send(self.msg_name.encode())
				con.__sock.send(data.encode())
		write_in_file()

def main():
    work = Thread(target=serv_work, args=[server])
    work.start()
    while (True):
        try:
            server.listen(1)
            sock, address = server.accept()
            newUser = multiServer(sock, address)
            newUser.start()
        except OSError:   # перехват ошибки 
            print("Сервер закрыт!")
            break

if __name__ == "__main__":
    main()

# также см. файл клиентской части client.py 